import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("startup_funding.csv", encoding='latin1')
print(df)
print("\nShape of the Data set: ",df.shape)
print("\nInformation of Data Set :",df.info())
print(df.isnull())
print("total null in columns", df.isnull().sum())
print("Total null elements in whole dataset", df.isnull().sum().sum())
print(df.describe())
# Clean column names
df.rename(columns={
    'ï»¿Sr No': 'Sr No',
    'Date dd/mm/yyyy': 'Date',
    'City  Location': 'City'
}, inplace=True)

# Convert 'Date' column to datetime
df['Date'] = pd.to_datetime(df['Date'], errors='coerce', dayfirst=True)

# Clean 'Amount in USD'
df['Amount in USD'] = df['Amount in USD'].str.replace(',', '')
df['Amount in USD'] = pd.to_numeric(df['Amount in USD'], errors='coerce')

# Fill missing values
df['City'] = df['City'].fillna("Unknown")
df['Industry Vertical'] = df['Industry Vertical'].fillna("Unknown")
df['Investors Name'] = df['Investors Name'].fillna("Unknown")

sns.set(style="whitegrid")

# 1. Funding Amount Distribution
plt.figure(figsize=(10,6))
sns.histplot(df['Amount in USD'].dropna(), bins=50, kde=True, color='skyblue')
plt.title("Distribution of Funding Amounts")
plt.xlabel("Amount in USD")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 6))
sns.boxplot(x=df['Amount in USD'].dropna(), color='salmon')
plt.title("Boxplot of Funding Amounts")
plt.xlabel("Amount in USD")
plt.tight_layout()
plt.show()

# 2. Funding Trend Over Time
df['Year'] = df['Date'].dt.year
funding_per_year = df.groupby('Year')['Amount in USD'].sum().dropna()

plt.figure(figsize=(10,6))
sns.lineplot(x=funding_per_year.index, y=funding_per_year.values, marker='o')
plt.title("Total Funding Amount per Year")
plt.xlabel("Year")
plt.ylabel("Total Funding (USD)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 3. City-wise Funding Analysis
city_funding = df.groupby('City')['Amount in USD'].sum().sort_values(ascending=False).head(10)
city_df = city_funding.reset_index()

plt.figure(figsize=(10,6))
sns.barplot(data=city_df, x='Amount in USD', y='City', hue='City', palette='viridis', legend=False)
plt.title("Top 10 Cities by Total Funding")
plt.xlabel("Total Funding (USD)")
plt.ylabel("City")
plt.tight_layout()
plt.show()

# 4. Industry-wise Funding as Heatmap
industry_funding = df.groupby('Industry Vertical')['Amount in USD'].sum().sort_values(ascending=False).head(10)
industry_df = industry_funding.reset_index()
industry_df.columns = ['Industry', 'Total Funding']

# Reshape for heatmap (Industry on y-axis, Funding as values)
heatmap_data = industry_df.pivot_table(index='Industry', values='Total Funding')

plt.figure(figsize=(10, 6))
sns.heatmap(heatmap_data, annot=True, fmt='.0f', cmap='coolwarm', linewidths=0.5, cbar_kws={"label": "Funding (USD)"})
plt.title("Heatmap of Top 10 Funded Industries")
plt.xlabel("Total Funding (USD)")
plt.ylabel("Industry")
plt.tight_layout()
plt.show()


# 5. Top Investors by Frequency
top_investors = df['Investors Name'].value_counts().head(10)
investors_df = top_investors.reset_index()
investors_df.columns = ['Investor', 'Count']

plt.figure(figsize=(10,6))
sns.barplot(data=investors_df, x='Count', y='Investor', hue='Investor', palette='mako', legend=False)
plt.title("Top 10 Most Active Investors")
plt.xlabel("Number of Investments")
plt.ylabel("Investor")
plt.tight_layout()
plt.show()
